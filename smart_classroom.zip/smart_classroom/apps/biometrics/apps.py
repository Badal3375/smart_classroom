from django.apps import AppConfig

class BiometricsConfig(AppConfig):
    name = "apps.biometrics"
    label = "biometrics"
